import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;

public class GuiElfo {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GuiElfo window = new GuiElfo();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GuiElfo() {
		initialize();
	}
	public void mostrar() {
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 434, 262);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		FabricaAbstracta fabrica = new FabricaElfos();
		Cliente cliente = new Cliente(fabrica);
		
		
		JPanel panel1 = new JPanel();
		Graphics g = panel1.getGraphics();
		Image img = cliente.Arma1();
		g.drawImage(img, dx1, dy1, dx2, dy2, null);
		
		JLabel label_1 = new JLabel(cliente.Cuerpo1());
		label_1.setBounds(247, 11, 140, 121);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel(cliente.Escudo1());
		label_2.setBounds(247, 133, 140, 118);
		panel.add(label_2);
		
		JButton volver = new JButton("Volver");
		volver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.setVisible(false);
				Gui Gui= new Gui();
				Gui.mostrar();
			}
		});
		volver.setBounds(172, 212, 89, 23);
		panel.add(volver);
	}

}
