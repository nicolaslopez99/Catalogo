import javax.swing.ImageIcon;
import javax.swing.JLabel;

abstract class AbstractoCuerpo {
	public abstract ImageIcon Mostrar();
	public abstract String Mostrar2(AbstractoCuerpo a);

}
