import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class CuerpoHombre extends AbstractoCuerpo{
	public String Mostrar2(AbstractoCuerpo hombre) {
		String resultado="mira ese cuerpo de hombre";
		return resultado;
	}
	private ImageIcon CuerpoHombre = new ImageIcon(new ImageIcon(getClass().getResource("/(default package)/armaHombre.png")).getImage());
	public ImageIcon Mostrar() {
		return CuerpoHombre;
	}
}
