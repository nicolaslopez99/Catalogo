import javax.swing.ImageIcon;
import javax.swing.JLabel;

abstract class AbstractoEscudo {
	public abstract ImageIcon Mostrar();
	public abstract String Mostrar2(AbstractoEscudo a);

}
