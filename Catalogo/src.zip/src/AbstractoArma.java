import javax.swing.ImageIcon;
import javax.swing.JLabel;

abstract class AbstractoArma {
	public abstract ImageIcon Mostrar(AbstractoArma a);
	public abstract String Mostrar2(AbstractoArma a);
}
